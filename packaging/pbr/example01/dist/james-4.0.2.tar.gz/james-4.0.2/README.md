# build the distribution
python setup.py sdist

# install the package
pip install .