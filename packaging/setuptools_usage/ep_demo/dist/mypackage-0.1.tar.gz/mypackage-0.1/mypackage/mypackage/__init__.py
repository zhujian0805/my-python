#!/usr/bin/python
"""
This is a testing package
"""

def main():
    print "This is main....!!!!!"
    print "Suck you!!!"
